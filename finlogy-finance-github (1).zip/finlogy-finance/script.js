"use strict";

const $ = id => document.getElementById(id);
const STORAGE = {
  transactions: "finlogy_transactions_v1",
  calculations: "finlogy_calculations_v1",
  stocks: "finlogy_stocks_v1",
  receipts: "finlogy_receipts_v1"
};

function load(key) {
  try {
    const data = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}
function save(key, data) {
  try { localStorage.setItem(key, JSON.stringify(data)); return true; }
  catch { alert("Could not save data in this browser. Export a backup and free up storage."); return false; }
}
let transactions = load(STORAGE.transactions);
let calculations = load(STORAGE.calculations);
let stocks = load(STORAGE.stocks);
let receipts = load(STORAGE.receipts);
let latestCalculation = null;
let cashChart = null;

const currencyConfig = {
  INR: { locale:"en-IN", digits:2 }, USD:{locale:"en-US",digits:2},
  EUR:{locale:"de-DE",digits:2}, GBP:{locale:"en-GB",digits:2},
  AED:{locale:"en-AE",digits:2}, OMR:{locale:"en-OM",digits:3},
  JPY:{locale:"ja-JP",digits:0}, AUD:{locale:"en-AU",digits:2}
};
function money(value, currency="INR") {
  const cfg = currencyConfig[currency] || {locale:"en-US",digits:2};
  return new Intl.NumberFormat(cfg.locale, {
    style:"currency", currency, minimumFractionDigits:cfg.digits, maximumFractionDigits:cfg.digits
  }).format(value);
}
function number(id) {
  const raw = $(id).value.trim();
  if (!raw) throw new Error("Please fill in all required fields.");
  const n = Number(raw);
  if (!Number.isFinite(n)) throw new Error("Enter a valid number.");
  return n;
}
function id(prefix) {
  return `${prefix}-${crypto.randomUUID ? crypto.randomUUID() : Date.now()+"-"+Math.random().toString(36).slice(2)}`;
}
function showError(target, error) {
  target.textContent = error.message || "Something went wrong.";
}

// Navigation
document.querySelectorAll(".nav-btn").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b === button));
    document.querySelectorAll(".page").forEach(page => page.classList.toggle("active", page.id === button.dataset.page));
    if (button.dataset.page === "receipts") renderReceipts();
  });
});
$("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  try { localStorage.setItem("finlogy_theme", document.body.classList.contains("dark") ? "dark" : "light"); } catch {}
});
try { if (localStorage.getItem("finlogy_theme") === "dark") document.body.classList.add("dark"); } catch {}
$("year").textContent = new Date().getFullYear();
$("transactionDate").value = new Date().toLocaleDateString("en-CA");

// Interest calculator
$("interestForm").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const principal = number("principal"), rate = number("rate"), years = number("years");
    const frequency = number("frequency"), type = $("interestType").value;
    if (principal < 0 || rate < 0 || rate > 1000 || years < 0 || years > 1000) {
      throw new Error("Enter non-negative values within the supported limits.");
    }
    let amount, interest;
    if (type === "simple") {
      interest = principal * rate / 100 * years;
      amount = principal + interest;
    } else {
      amount = principal * Math.pow(1 + rate / (100 * frequency), frequency * years);
      interest = amount - principal;
    }
    if (!Number.isFinite(amount) || !Number.isFinite(interest)) throw new Error("Result exceeds the supported numeric range.");
    latestCalculation = {
      id:id("calc"), type, principal, rate, years,
      frequency:type === "compound" ? frequency : null,
      interest, amount, currency:"INR", createdAt:new Date().toISOString()
    };
    const target = $("interestResult");
    target.replaceChildren();
    [["Principal",money(principal)],["Interest",money(interest)],["Final amount",money(amount)]].forEach(([label,value]) => {
      const p = document.createElement("p"); p.textContent = `${label}: ${value}`; target.appendChild(p);
    });
    $("saveCalculation").disabled = false;
  } catch (error) {
    latestCalculation = null; $("saveCalculation").disabled = true; showError($("interestResult"), error);
  }
});
$("saveCalculation").addEventListener("click", () => {
  if (!latestCalculation) return;
  const next = [...calculations, latestCalculation];
  if (!save(STORAGE.calculations, next)) return;
  calculations = next; latestCalculation = null; $("saveCalculation").disabled = true;
  renderCalculations(); updateDashboard(); alert("Calculation saved in this browser.");
});

// EMI calculator
$("emiForm").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const principal = number("loanAmount"), annualRate = number("loanRate"), years = number("loanYears");
    if (principal <= 0 || annualRate < 0 || annualRate > 1000 || years <= 0 || years > 100) {
      throw new Error("Enter a positive loan amount and valid rate and tenure.");
    }
    const n = Math.round(years * 12), r = annualRate / 1200;
    const emi = r === 0 ? principal / n : principal * r * Math.pow(1+r,n) / (Math.pow(1+r,n)-1);
    $("emiResult").textContent = `Monthly EMI: ${money(emi)} | Total interest: ${money(emi*n-principal)} | Total repayment: ${money(emi*n)} | Payments: ${n}`;
  } catch (error) { showError($("emiResult"), error); }
});

// ROI calculator
$("roiForm").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const initial = number("roiInitial"), finalValue = number("roiFinal");
    if (initial <= 0 || finalValue < 0) throw new Error("Initial investment must be positive and final value cannot be negative.");
    $("roiResult").textContent = `Profit / Loss: ${money(finalValue-initial)} | ROI: ${((finalValue-initial)/initial*100).toFixed(2)}%`;
  } catch (error) { showError($("roiResult"), error); }
});

// Forex uses an external rate source; no exchange rates are hardcoded.
$("forexForm").addEventListener("submit", async event => {
  event.preventDefault();
  const target = $("forexResult");
  target.textContent = "Fetching exchange rate…";
  try {
    const amount = number("forexAmount"), from = $("fromCurrency").value, to = $("toCurrency").value;
    if (amount < 0) throw new Error("Amount cannot be negative.");
    if (from === to) { target.textContent = `${money(amount,from)} = ${money(amount,to)}. Same currency.`; return; }
    const url = `https://api.frankfurter.dev/v1/latest?base=${encodeURIComponent(from)}&symbols=${encodeURIComponent(to)}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error("Exchange-rate service is unavailable for this currency pair.");
    const data = await response.json(), rate = data.rates && data.rates[to];
    if (!Number.isFinite(rate) || rate <= 0) throw new Error("No valid exchange rate is available.");
    target.textContent = `${money(amount,from)} = ${money(amount*rate,to)} | Rate: ${rate} ${to}/${from} | Rate date: ${data.date}. Indicative only; fees may apply.`;
  } catch (error) { showError(target,error); }
});

// Transactions
$("newTransaction").addEventListener("click", () => {
  document.querySelector('[data-page="transactions"]').click();
  $("transactionDescription").focus();
});
$("transactionForm").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const description = $("transactionDescription").value.trim();
    const type = $("transactionType").value, amount = number("transactionAmount");
    const currency = $("transactionCurrency").value, date = $("transactionDate").value;
    if (!description || description.length > 120) throw new Error("Enter a description of up to 120 characters.");
    if (!["income","expense"].includes(type)) throw new Error("Invalid transaction type.");
    if (amount <= 0 || !date || Number.isNaN(Date.parse(date))) throw new Error("Enter a valid positive amount and date.");
    const txn = {id:id("txn"),description,type,amount,currency,date,createdAt:new Date().toISOString()};
    const next = [...transactions,txn];
    if (!save(STORAGE.transactions,next)) return;
    transactions = next; event.target.reset(); $("transactionDate").value = new Date().toLocaleDateString("en-CA");
    renderTransactions(); updateDashboard(); alert("Transaction saved in this browser.");
  } catch (error) { alert(error.message || "Could not save transaction."); }
});
function renderTransactions() {
  const tbody = $("transactionRows"); tbody.replaceChildren();
  [...transactions].reverse().forEach(txn => {
    const tr = document.createElement("tr");
    [txn.date,txn.description,txn.type,money(txn.amount,txn.currency)].forEach(value => {
      const td = document.createElement("td"); td.textContent = value; tr.appendChild(td);
    });
    const td = document.createElement("td"), receiptButton = document.createElement("button");
    receiptButton.className = "secondary-btn"; receiptButton.textContent = "Receipt";
    receiptButton.addEventListener("click", () => {
      document.querySelector('[data-page="receipts"]').click(); $("receiptTransaction").value = txn.id;
    });
    td.appendChild(receiptButton); tr.appendChild(td); tbody.appendChild(tr);
  });
  const select = $("receiptTransaction"), selected = select.value; select.replaceChildren();
  transactions.forEach(txn => {
    const option = document.createElement("option"); option.value = txn.id;
    option.textContent = `${txn.date} — ${txn.description} — ${money(txn.amount,txn.currency)}`;
    select.appendChild(option);
  });
  if (transactions.some(txn => txn.id === selected)) select.value = selected;
}
function updateDashboard() {
  const inr = transactions.filter(t => t.currency === "INR").reduce((totals,t) => {
    totals[t.type] += t.amount; return totals;
  },{income:0,expense:0});
  $("incomeTotal").textContent = money(inr.income);
  $("expenseTotal").textContent = money(inr.expense);
  $("cashFlow").textContent = money(inr.income-inr.expense);
  $("calculationCount").textContent = calculations.length;
  const recent = $("recentTransactions"); recent.replaceChildren();
  [...transactions].reverse().slice(0,5).forEach(txn => {
    const tr = document.createElement("tr");
    [txn.date,txn.description,txn.type,money(txn.amount,txn.currency)].forEach(value => {
      const td = document.createElement("td"); td.textContent = value; tr.appendChild(td);
    });
    recent.appendChild(tr);
  });
  if (typeof Chart === "undefined") return;
  if (cashChart) cashChart.destroy();
  cashChart = new Chart($("cashChart"), {
    type:"bar", data:{labels:["Income (INR)","Expenses (INR)"],datasets:[{label:"Recorded amounts",data:[inr.income,inr.expense],backgroundColor:["#167453","#e59c64"]}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}
  });
}

// Manual stock records only
$("stockForm").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const symbol = $("stockSymbol").value.trim().toUpperCase();
    const quantity = number("stockQuantity"), price = number("stockPrice"), currency = $("stockCurrency").value;
    if (!/^[A-Z0-9.-]{1,20}$/.test(symbol) || quantity <= 0 || price < 0) throw new Error("Enter a valid symbol, positive quantity and non-negative price.");
    const next = [...stocks,{id:id("stock"),symbol,quantity,price,currency,createdAt:new Date().toISOString()}];
    if (!save(STORAGE.stocks,next)) return;
    stocks = next; renderStocks(); event.target.reset();
  } catch (error) { alert(error.message); }
});
function renderStocks() {
  const tbody = $("stockRows"); tbody.replaceChildren();
  stocks.forEach(stock => {
    const tr = document.createElement("tr");
    [stock.symbol,stock.quantity,money(stock.price,stock.currency),money(stock.quantity*stock.price,stock.currency)].forEach(value => {
      const td = document.createElement("td"); td.textContent = String(value); tr.appendChild(td);
    });
    const td = document.createElement("td"), remove = document.createElement("button");
    remove.className = "secondary-btn"; remove.textContent = "Delete";
    remove.addEventListener("click", () => {
      if (!confirm("Delete this holding record?")) return;
      const next = stocks.filter(s => s.id !== stock.id);
      if (save(STORAGE.stocks,next)) { stocks = next; renderStocks(); }
    });
    td.appendChild(remove); tr.appendChild(td); tbody.appendChild(tr);
  });
}

// PDF receipt generated from a saved transaction snapshot.
$("generateReceipt").addEventListener("click", () => {
  try {
    const txn = transactions.find(item => item.id === $("receiptTransaction").value);
    if (!txn) throw new Error("Save a transaction before generating a receipt.");
    if (!window.jspdf || !window.jspdf.jsPDF) throw new Error("PDF library is unavailable. Reload and try again.");
    const receipt = {id:id("receipt"),transactionId:txn.id,number:`FF-${Date.now()}`,issuedAt:new Date().toISOString(),snapshot:{...txn}};
    const next = [...receipts,receipt];
    if (!save(STORAGE.receipts,next)) return;
    receipts = next;
    const pdf = new window.jspdf.jsPDF();
    pdf.setFontSize(20); pdf.text("FINLOGY FINANCE",20,25);
    pdf.setFontSize(11);
    [
      ["TRANSACTION RECEIPT — PERSONAL RECORD",35],
      [`Receipt number: ${receipt.number}`,50],
      [`Transaction ID: ${txn.id}`,60],
      [`Issue date: ${receipt.issuedAt}`,70],
      [`Description: ${txn.description}`,85],
      [`Type: ${txn.type}`,95],
      [`Transaction date: ${txn.date}`,105],
      [`Amount: ${money(txn.amount,txn.currency)}`,115]
    ].forEach(([text,y]) => pdf.text(String(text),20,y));
    pdf.setFontSize(9);
    pdf.text("Generated application record; not a bank or payment-provider confirmation.",20,140);
    pdf.save(`${receipt.number}.pdf`);
    $("receiptResult").textContent = `Receipt ${receipt.number} created for saved transaction ${txn.id}.`;
    renderReceipts();
  } catch (error) { showError($("receiptResult"),error); }
});
function renderReceipts() {
  const container = $("receiptRows"); container.replaceChildren();
  receipts.forEach(receipt => {
    const p = document.createElement("p");
    p.textContent = `${receipt.number} — Transaction ${receipt.transactionId} — ${new Date(receipt.issuedAt).toLocaleString()}`;
    container.appendChild(p);
  });
}
function renderCalculations() {
  const container = $("calculationRows"); container.replaceChildren();
  [...calculations].reverse().forEach(calc => {
    const p = document.createElement("p");
    p.textContent = `${calc.type} | Principal: ${money(calc.principal,calc.currency)} | Interest: ${money(calc.interest,calc.currency)} | Total: ${money(calc.amount,calc.currency)} | ${new Date(calc.createdAt).toLocaleString()}`;
    container.appendChild(p);
  });
}

// CSV export: quote fields and guard spreadsheet formula injection.
$("exportCSV").addEventListener("click", () => {
  const csvField = value => {
    let text = String(value ?? "");
    if (/^[\s]*[=+\-@]/.test(text)) text = "'" + text;
    return `"${text.replace(/"/g,'""')}"`;
  };
  const rows = [["ID","Date","Description","Type","Amount","Currency"],...transactions.map(t => [t.id,t.date,t.description,t.type,t.amount,t.currency])];
  downloadBlob(rows.map(row => row.map(csvField).join(",")).join("\r\n"),"finlogy-transactions.csv","text/csv;charset=utf-8;");
});
$("backupJSON").addEventListener("click", () => downloadBlob(
  JSON.stringify({exportedAt:new Date().toISOString(),transactions,calculations,stocks,receipts},null,2),
  "finlogy-backup.json","application/json"
));
function downloadBlob(content,filename,type) {
  const blob = new Blob([content],{type}), url = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url),1000);
}

// Initial render
renderTransactions(); renderStocks(); renderCalculations(); renderReceipts(); updateDashboard();
